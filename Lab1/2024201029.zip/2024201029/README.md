## Submisssion

Folder contain to bash script corresponding to 2 question.

### Q1

It is assumed that the log file is present in the same folder bash script is present. To run the script type :

`./2024201029/2024201029_q1.sh`

### Q2

It is assumed that the log file is present in the same folder bash script is present. To run the script type :

`./2024201029/2024201029_q2.sh`
